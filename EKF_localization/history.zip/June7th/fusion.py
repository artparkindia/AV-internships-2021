#LIDAR GPS IMU FUSION
#uses ONLY [Vel_X,Vel_Y,Omega] measurements from IMU
#X,Y, Theta from LIDAR
#X,Y from GPS

import numpy as np
import pykitti
import matplotlib.pyplot as plt
import math
import pandas as pd
import itertools
import toml


#Read the TOML config file
params = toml.load("fusion_config.toml")
basedir = params.get("basedir")
date = params.get("date")
drive = params.get("drive")

dataset = pykitti.raw(basedir, date, drive)
oxts = dataset.oxts
time_stamp = dataset.timestamps
N = len(oxts) - 5

# Extract pre-generated LIDAR ICP and GPS data
pose_lidar = np.array(np.loadtxt('LIDAR_' + date + '_' + drive + ".txt"))
pose_gps = np.array(np.loadtxt('GPS_' + date + '_' + drive + ".txt"))


#Process noise parameters
sigma_ax2 = params.get("sigma_ax2")
sigma_ay2 = params.get("sigma_ay2")
#Measurement noise parameters: Lidar
sigma_x2_lid = params.get("sigma_x2_lid")
sigma_y2_lid = params.get("sigma_y2_lid")
sigma_theta_lid = params.get("sigma_theta_lid")
#Measurement noise parameters: GPS
sigma_x2_gps = params.get("sigma_x2_gps")
sigma_y2_gps = params.get("sigma_y2_gps")
#Measurement noise params : IMU
#sigma_theta_imu = params.get("sigma_theta_imu")
sigma_omega_imu = params.get("sigma_omega_imu")
sigma_velx_imu = params.get("sigma_vel_imu")
sigma_vely_imu = params.get("sigma_vel_imu")


#initialization
P = np.asarray([[10,0,0,0,0,0],[0,10,0,0,0,0],[0,0,1,0,0,0],[0,0,0,10,0,0],[0,0,0,0,10,0],[0,0,0,0,0,10]])
X = np.asarray([[1],[1],[0.0],[1],[1],[1]])

#GPS
HGps = np.asarray([[1,0,0,0,0,0],[0,1,0,0,0,0]])
RGps = np.asarray([[sigma_x2_gps,0],[0,sigma_y2_gps]]) 

#IMU
HImu = np.asarray([[0,0,0,1,0,0],[0,0,0,0,1,0],[0,0,0,0,0,1]])
RImu = np.asarray([[sigma_velx_imu,0,0],[0,sigma_vely_imu,0],[0,0,sigma_omega_imu]])  

#Lidar
HLidar = np.asarray([[1,0,0,0,0,0],[0,1,0,0,0,0],[0,0,1,0,0,0]])
#noise covariance
RLidar = np.asarray([[sigma_x2_lid,0,0],[0,sigma_y2_lid,0],[0,0,sigma_theta_lid]]) 


# STATE MATRIX
xpos=[]
ypos=[]
theta = []
vx=[]
vy = []
omega = []

# LIDAR Measurements
xpos_lidar=[]
ypos_lidar = []
theta_lidar = []

#GPS Measurements
xpos_gps=[]
ypos_gps = []

# IMU Measurements
theta_imu = []
omega_imu = []
velx_imu = []
vely_imu = []

#Number of states
Lidarstates = 3 #x,y,theta
Gpsstates = 2   #x,y
Imustates = 3   #velx,vely,omega

#Process covariance
def Q(state):
    return np.asarray([[0.14/dt,0,0,0,0,0],
                      [0,0.19/dt,0,0,0,0],
                      [0,0,0.22/dt,0,0,0],
                      [0,0,0,0.28/dt,0,0],
                      [0,0,0,0,0.35/dt,0],
                      [0,0,0,0,0,0.40/dt]])
    
       
def Fmatrix(state):
    x,y,theta,vx,vy,w = tuple(np.concatenate(state))
    return np.asarray([[1,0,0,dt,0,0],
                       [0,1,0,0,dt,0],
                       [0,0,1,0,0,dt],
                       [0,0,0,1,0,0],
                       [0,0,0,0,1,0],
                       [0,0,0,0,0,1]])
    
def predict(X,P):
        F = Fmatrix(X)
        X = np.matmul(F,X)
        P = np.add(np.matmul(np.asarray(np.matmul(F,P)),np.transpose(F)),Q(dt))
        return X,P
    
def correct_gps(X,P,Z):
        S=np.matmul(np.matmul(HGps,P),np.transpose(HGps))+RGps  
        K = np.dot(np.matmul(P,np.transpose(HGps)),np.linalg.inv(S))
        y=np.reshape(np.asarray(Z[0:Gpsstates]),(Gpsstates,1))-np.matmul(HGps,X)
        X = np.add(X,np.dot(K,y))
        P = np.matmul(np.identity(len(X))-np.matmul(K,HGps),P)
        return X,P
    
def correct_lidar(X,P,Z):
        S=np.matmul(np.matmul(HLidar,P),np.transpose(HLidar)) + RLidar  
        K = np.dot(np.matmul(P,np.transpose(HLidar)),np.linalg.inv(S))
        y=np.reshape(np.asarray(Z[0:Lidarstates]),(Lidarstates,1))-np.matmul(HLidar,X)
        X = np.add(X,np.dot(K,y))
        P = np.matmul(np.identity(len(X))-np.matmul(K,HLidar),P)
        return X,P
    
def correct_imu(X,P,Z):
        S=np.matmul(np.dot(HImu,P),np.transpose(HImu)) + RImu 
        K = np.dot(np.dot(P,np.transpose(HImu)),np.linalg.inv(S))
        y = np.reshape(np.asarray(Z[0:Imustates]),(Imustates,1))-np.matmul(HImu,X)
        X = np.add(X,np.dot(K,y))
        P = np.dot(np.identity(len(X))-np.dot(K,HImu),P)
        return X,P
        

for i in range(0,N):
    
    dt = (time_stamp[i].microsecond - time_stamp[i-1].microsecond)/10000.0    #10000.0
    prev_timestamp = time_stamp[i].microsecond
    
    #copy measurements from dataset
    xpos_lidar.append(pose_lidar[i][0])
    ypos_lidar.append(pose_lidar[i][1])
    theta_lidar.append(pose_lidar[i][2])
    xpos_gps.append(pose_gps[i][0])
    ypos_gps.append(pose_gps[i][1])
    
    #theta_imu.append(oxts[i].packet.yaw)
    omega_imu.append(oxts[i].packet.wz)
    velx_imu.append(oxts[i].packet.vf)
    vely_imu.append(oxts[i].packet.vl)
    
    X,P = predict(X,P)
    if(oxts[i].packet.numsats > 3 and abs(velx_imu[i]) > 0.01):  #if number of satellites < 3 and forward_vel ~= 0, reject GPS measurement
        X,P = correct_gps(X,P,pose_gps[i])
    X,P = correct_lidar(X,P,pose_lidar[i])
    X,P = correct_imu(X,P,np.asarray([velx_imu[i],vely_imu[i],omega_imu[i]])) 
    
    xpos.append(X[0])
    ypos.append(X[1])
    theta.append(X[2])
    vx.append(X[3])
    vy.append(X[4])
    omega.append(X[5])
    
    
xpos = list(itertools.chain.from_iterable(xpos))
ypos = list(itertools.chain.from_iterable(ypos))
theta = list(itertools.chain.from_iterable(theta))
vx = list(itertools.chain.from_iterable(vx))
vy = list(itertools.chain.from_iterable(vy))
omega = list(itertools.chain.from_iterable(omega))


plt.figure(figsize=(12,8))
plt.plot(xpos_lidar,ypos_lidar,label='Measured by Lidar', color = 'g')
plt.plot(xpos_gps,ypos_gps,label='Measured by GPS',color='b')
plt.plot(xpos,ypos,label='EKF - Lidar+GPS+IMU',color='r',ls='--')
plt.xlabel('X-coordinate')
plt.ylabel('Y-coordinate')
plt.legend()
plt.show()
