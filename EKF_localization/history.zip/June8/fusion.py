#LIDAR GPS IMU FUSION
#uses ONLY [Vel_X,Omega] measurements from IMU
#X,Y, Theta from LIDAR
#X,Y from GPS

import numpy as np
import pykitti
import matplotlib.pyplot as plt
import math
import pandas as pd
import itertools
import toml


#Read the TOML config file
params = toml.load("fusion_config.toml")
basedir = params.get("basedir")
date = params.get("date")
drive = params.get("drive")

dataset = pykitti.raw(basedir, date, drive)
oxts = dataset.oxts
time_stamp = dataset.timestamps
N = len(oxts) - 5

# Extract pre-generated LIDAR ICP and GPS data
pose_lidar = np.array(np.loadtxt('LIDAR_' + date + '_' + drive + ".txt"))
pose_gps = np.array(np.loadtxt('GPS_' + date + '_' + drive + ".txt"))


#Process noise parameters
sigma_ax2 = params.get("sigma_ax2")
sigma_ay2 = params.get("sigma_ay2")
#Measurement noise parameters: Lidar
sigma_x2_lid = params.get("sigma_x2_lid")
sigma_y2_lid = params.get("sigma_y2_lid")
sigma_theta_lid = params.get("sigma_theta_lid")
#Measurement noise parameters: GPS
sigma_x2_gps = params.get("sigma_x2_gps")
sigma_y2_gps = params.get("sigma_y2_gps")
#Measurement noise params : IMU
#sigma_theta_imu = params.get("sigma_theta_imu")
sigma_omega_imu = params.get("sigma_omega_imu")
sigma_velx_imu = params.get("sigma_vel_imu")


#initialization
P = np.asarray([[10,0,0,0,0,0],[0,10,0,0,0,0],[0,0,1,0,0,0],[0,0,0,10,0,0],[0,0,0,0,10,0],[0,0,0,0,0,10]])
X = np.asarray([[1],[1],[0.0],[1],[1],[1]])

#GPS
HGps = np.asarray([[1,0,0,0,0,0],[0,1,0,0,0,0]])
RGps = np.asarray([[sigma_x2_gps,0],[0,sigma_y2_gps]]) 

#Lidar
HLidar = np.asarray([[1,0,0,0,0,0],[0,1,0,0,0,0],[0,0,1,0,0,0]])
RLidar = np.asarray([[sigma_x2_lid,0,0],[0,sigma_y2_lid,0],[0,0,sigma_theta_lid]]) 


# STATE MATRIX
xpos=[]
ypos=[]
theta = []
vx=[]
vy = []
omega = []

# LIDAR Measurements
xpos_lidar=[]
ypos_lidar = []
theta_lidar = []

#GPS Measurements
xpos_gps=[]
ypos_gps = []

# IMU measurements for process model
theta_imu = []
omega_imu = []
velx_imu = []

#Number of states
Lidarstates = 3 #x,y,theta
Gpsstates = 2   #x,y

#Process covariance
def Q(state):
    return np.asarray([[0.15,0,0,0,0,0],
                      [0,0.20,0,0,0,0],
                      [0,0,0.25,0,0,0],
                      [0,0,0,0.30,0,0],
                      [0,0,0,0,0.35,0],
                      [0,0,0,0,0,0.40]])
    
       
def Fmatrix(state):
    x,y,theta,vx,vy,w = tuple(np.concatenate(state))
    return np.asarray([[1,0,0,dt,0,0],
                       [0,1,0,0,dt,0],
                       [0,0,1,0,0,dt],
                       [0,0,0,1,0,0],
                       [0,0,0,0,1,0],
                       [0,0,0,0,0,1]])

def Bmatrix(dt):
    return np.asarray([[dt,0],
                       [0,0],
                       [0,dt],
                       [1,0],
                       [0,0],
                       [0,1]])

    
def predict_with_imu(X,P,Z):
        F = Fmatrix(X)
        B = Bmatrix(dt)
        u = np.asarray([velx_imu[i],omega_imu[i]])  
        X = np.matmul(F,X) + np.matmul(B,u).reshape(6,1)
        P = np.add(np.matmul(np.asarray(np.matmul(F,P)),np.transpose(F)),Q(dt))
        return X,P
    
def predict(X,P):
        F = Fmatrix(X)
        X = np.matmul(F,X)
        P = np.add(np.matmul(np.asarray(np.matmul(F,P)),np.transpose(F)),Q(dt))
        return X,P
    
    
def correct_gps(X,P,Z):
        S=np.matmul(np.matmul(HGps,P),np.transpose(HGps))+RGps  
        K = np.dot(np.matmul(P,np.transpose(HGps)),np.linalg.inv(S))
        y=np.reshape(np.asarray(Z[0:Gpsstates]),(Gpsstates,1))-np.matmul(HGps,X)
        X = np.add(X,np.dot(K,y))
        P = np.matmul(np.identity(len(X))-np.matmul(K,HGps),P)
        return X,P
    
def correct_lidar(X,P,Z):
        S=np.matmul(np.matmul(HLidar,P),np.transpose(HLidar)) + RLidar  
        K = np.dot(np.matmul(P,np.transpose(HLidar)),np.linalg.inv(S))
        y=np.reshape(np.asarray(Z[0:Lidarstates]),(Lidarstates,1))-np.matmul(HLidar,X)
        X = np.add(X,np.dot(K,y))
        P = np.matmul(np.identity(len(X))-np.matmul(K,HLidar),P)
        return X,P

for i in range(0,N):
    
    dt = (time_stamp[i].microsecond - time_stamp[i-1].microsecond)/1000000.0    #1000000.0
    
    #copy measurements from dataset
    xpos_lidar.append(pose_lidar[i][0])
    ypos_lidar.append(pose_lidar[i][1])
    theta_lidar.append(pose_lidar[i][2])
    xpos_gps.append(pose_gps[i][0])
    ypos_gps.append(pose_gps[i][1])
    omega_imu.append(oxts[i].packet.wz)
    velx_imu.append(oxts[i].packet.vf)
    
    #X,P = predict_with_imu(X,P,np.array([[velx_imu,omega_imu]]))
    X,P = predict(X,P)
    if(oxts[i].packet.numsats > 3 and abs((xpos_gps[i] - xpos_gps[i-1])/dt) > 0.1):  #if number of satellites < 3 and forward_vel ~= 0, reject GPS measurement
        X,P = correct_gps(X,P,pose_gps[i])
    X,P = correct_lidar(X,P,pose_lidar[i])
    
    xpos.append(X[0])
    ypos.append(X[1])
    theta.append(X[2])
    vx.append(X[3])
    vy.append(X[4])
    omega.append(X[5])
    
    
xpos = list(itertools.chain.from_iterable(xpos))
ypos = list(itertools.chain.from_iterable(ypos))
theta = list(itertools.chain.from_iterable(theta))
vx = list(itertools.chain.from_iterable(vx))
vy = list(itertools.chain.from_iterable(vy))
omega = list(itertools.chain.from_iterable(omega))


plt.figure(figsize=(12,8))
plt.plot(xpos_lidar,ypos_lidar,label='Measured by Lidar', color = 'g')
plt.plot(xpos_gps,ypos_gps,label='Measured by GPS',color='b')
plt.plot(xpos,ypos,label='EKF - Lidar+GPS+IMU',color='r',ls='--')
plt.xlabel('X-coordinate')
plt.ylabel('Y-coordinate')
plt.legend()
plt.show()
